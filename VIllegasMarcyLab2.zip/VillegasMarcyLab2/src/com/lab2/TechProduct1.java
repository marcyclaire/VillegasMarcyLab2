package com.lab2;

public class TechProduct1 { //Parent or Super class

	 public String name;
	 public double price;
	 public int quantity;
	
	 //first constructor
	 public TechProduct1() {
		 
	 }
	 
	 //second constructor
	 public TechProduct1(String name, double price, int quantity) {
		 this.name = name;
		 this.price = price;
		 this.quantity = quantity;
	 }
	 
	 //setter methods
	 public void setName(String name) {
		 this.name = name;
	 }
	 
	 public void setPrice(double price) {
		 this.price = price;
	 }
	 
	 public void setQuantity(int quantity) {
		 this.quantity = quantity;
	 }
	 
	 //getter or accessor methods
	 public String getName() {
	    return name;
	 }
	    
	 public double getPrice() {
	     return price;
	 }
	    
	public int getQuantity() {
		 return quantity;
	 }
	 
	//Method that will give the total ammount of a certain product
	public double totalAmmount() {
		return quantity * price;
	}
	
}
