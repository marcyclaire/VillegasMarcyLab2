package com.lab2;

public class Test {

	public static void main(String[] args) {

		System.out.println("This are the products you bought: \n");
		
		//first constructor in Super class
		TechProduct1 phone1 = new TechProduct1();
		phone1.setName("Vivo Phone");
		phone1.setPrice(5000);
		phone1.setQuantity(2);
		System.out.println("Name: " + phone1.getName());
		System.out.println("Price: " + phone1.getPrice());
		System.out.println("Quantity: " + phone1.getQuantity());
		System.out.println("Total amount for this product: " + phone1.totalAmmount() + "\n");

		//second constructor in Super class
		TechProduct1 phone2 = new TechProduct1("Oppo Phone", 6000, 3);
		System.out.println("Name: " + phone2.getName());
		System.out.println("Price: " + phone2.getPrice());
		System.out.println("Quantity: " + phone2.getQuantity());
		System.out.println("Total amount for this product: " + phone2.totalAmmount() + "\n");
		
		//first constructor in Child class
		TechProduct2 laptop1 = new TechProduct2();
		laptop1.setName("HP Laptop");
		laptop1.setPrice(15000);
		laptop1.setInch(13);
		laptop1.setQuantity(4);
		System.out.println("Name: " + laptop1.getName());
		System.out.println("Price: " + laptop1.getPrice());
		System.out.println("Inch: " + laptop1.getInch());
		System.out.println("Quantity: " + laptop1.getQuantity());
		//Method overriding happens here:
		System.out.println("Total amount for this product: " + laptop1.totalAmmount() + "\n");

		//second constructor in Child class
		TechProduct2 laptop2 = new TechProduct2("Lenovo Laptop", 20000, 1, 15);
		System.out.println("Name: " + laptop2.getName());
		System.out.println("Price: " + laptop2.getPrice());
		System.out.println("Inch: " + laptop2.getInch());
		System.out.println("Quantity: " + laptop2.getQuantity());
		//Method overriding happens here:
		System.out.println("Total amount for this product: " + phone2.totalAmmount() + "\n");
		
		//Method overloading happens here:
		System.out.println("These are the free items for buying the products...");
		System.out.print("For the phones: ");
		System.out.println(laptop1.freeItems("Earphones","Temper Glass"));
		System.out.print("For the laptops: ");
		System.out.print(laptop1.freeItems("USB Flashdrive","Bluetooth Mouse","Keyboard"));
	}
}