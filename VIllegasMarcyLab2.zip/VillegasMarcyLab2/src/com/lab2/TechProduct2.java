package com.lab2;

public class TechProduct2 extends TechProduct1{ //Child or Sub class

	int inch;
	
	//first constructor
	public TechProduct2() {
		
	}
	
	//second constructor
	public TechProduct2(String name, double price, int quantity, int inch) {
		super(name, price, quantity);
		this.inch = inch;
	}
	
	//set method
	public void setInch(int inch) {
		this.inch = inch;
	}
	
	//get method
	public int getInch() {
		return this.inch;
	}
	
	//Method Overloading
	public String freeItems(String item1, String item2) {
		return item1 + ", " + item2;
	}
	
	public String freeItems(String item1, String item2, String item3) {
		return item1 + ", " + item2 + ", " + item3;
	}
	
}
